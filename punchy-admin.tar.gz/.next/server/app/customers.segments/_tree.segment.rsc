:HL["/_next/static/chunks/1xwsx2p52r1id.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(admin)","param":null,"prefetchHints":4192,"slots":{"children":{"name":"customers","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"YjOVkDRkKbvzwtp6iM6go"}
