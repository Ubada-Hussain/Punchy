module.exports=[57048,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_nfc-qr_page_actions_0_gv00i.js.map