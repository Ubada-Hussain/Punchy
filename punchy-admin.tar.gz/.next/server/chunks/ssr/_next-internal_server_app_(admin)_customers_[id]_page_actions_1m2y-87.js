module.exports=[93444,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_customers_%5Bid%5D_page_actions_1m2y-87.js.map