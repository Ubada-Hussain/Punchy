module.exports=[12468,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_customers_page_actions_1lpgux4.js.map