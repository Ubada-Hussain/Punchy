module.exports=[47388,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_settings_page_actions_17mrq50.js.map