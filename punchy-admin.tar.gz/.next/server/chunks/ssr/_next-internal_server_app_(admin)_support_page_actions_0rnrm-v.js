module.exports=[78217,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_support_page_actions_0rnrm-v.js.map